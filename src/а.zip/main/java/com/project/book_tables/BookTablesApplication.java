package com.project.book_tables;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookTablesApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookTablesApplication.class, args);
    }

}
